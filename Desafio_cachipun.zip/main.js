///variables

let maquina;
let movmaquina;
let user;
let movuser;
let resultado;

function aleatorio(min,max){
    return Math.random()*(max-min)+min
}

maquina=Math.floor(aleatorio(1,3))

///movimiento de maquina

if (maquina == 1) {
  movmaquina = "piedra";
}

if (maquina == 2) {
  movmaquina = "papel";
}

if (maquina == 3) {
  movmaquina = "tijeras";
}


//movimiento de usuario

user = +prompt(
  "Bienvenido! por favor eliga el numéro de su movimiento: \n 1. piedra  \n 2. papel  \n 3. tijeras "
);

if (user == 1) {
  movuser = "piedra";
}

if (user == 2) {
  movuser = "papel";
}

if (user == 3) {
  movuser = "tijeras";
}

document.write("la maquina saca: " +movmaquina +"<br>") ;
document.write("el usuario saca: " +movuser +"<br>");


/// Si Maquina saca piedra

if (movmaquina =="piedra" && movuser == "piedra") {
    resultado="empate!"
    alert("empate!")
  }

  if (movmaquina =="piedra" && movuser == "papel") {
     resultado= "Papel le gana a Piedra, Usuario Gana! Felicidades!!";
    alert("Papel le gana a Piedra, Usuario Gana! Felicidades!!")
      }

      if (movmaquina =="piedra" && movuser == "tijeras") {
resultado= "Piedra le gana a tijeras, Maquina gana! Intente de nuevo !";
alert("Piedra le gana a tijeras, Maquina gana! Intente de nuevo !")
          }      


/// Si Maquina saca Papel

if (movmaquina =="papel" && movuser == "piedra") {
    resultado= "Papel le gana a Piedra, Maquina gana! Intente de nuevo! ";
    alert("Papel le gana a Piedra, Maquina gana! Intente de nuevo!")
      }
    
      if (movmaquina =="papel" && movuser == "papel") {
        resultado="Empate!";
        alert("Empate!")
          }
    
          if (movmaquina =="papel" && movuser == "tijeras") {
            resultado="Tijeras le gana a Papel, Usuario Gana! Felicidades!!";
            alert("Tijeras le gana a Papel, Usuario Gana! Felicidades!!")
              }      


/// Si maquina saca Tijeras


if (movmaquina =="tijeras" && movuser == "piedra") {
    resultado="Piedra le gana a tijeras! Usuario Gana!";
    alert("Piedra le gana a tijeras! Usuario Gana!")

      }
    

      if (movmaquina =="tijeras" && movuser == "papel") {
        resultado="Tijeras le gana a Papel , Maquina Gana! Intente de nuevo !";
        alert("Tijeras le gana a Papel , Maquina Gana! Intente de nuevo !")
          }
    
          if (movmaquina =="tijeras" && movuser == "tijeras") {
            resultado= "Empate!";
            alert("Empate!")
              }      
    


